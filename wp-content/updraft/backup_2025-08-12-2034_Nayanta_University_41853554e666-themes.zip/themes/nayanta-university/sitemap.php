<?php
/* Template Name: Sitemap */

if (!defined('ABSPATH')) {
    exit;
}
get_header();
?>
 
<?php the_content(); ?>
 

<?php get_footer(); ?>